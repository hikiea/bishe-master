package com.example.demo.exception;

public interface ICustomErrorCode {
    String getMessage();
    Integer getCode();
}
