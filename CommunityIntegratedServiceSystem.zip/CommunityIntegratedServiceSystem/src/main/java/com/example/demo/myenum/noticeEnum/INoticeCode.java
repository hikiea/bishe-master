package com.example.demo.myenum.noticeEnum;

public interface INoticeCode {
    Integer getCode();
    String getType();
}
