package com.example.demo.myenum.roleEnum;


public interface IRoleCode {
    String getRole();
    Integer getCode();
}
