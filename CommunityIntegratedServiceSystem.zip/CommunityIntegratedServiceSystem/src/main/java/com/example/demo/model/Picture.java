package com.example.demo.model;

import lombok.Data;

@Data
public class Picture {

    private String pictureName;
    private String pictureAddress;

}
