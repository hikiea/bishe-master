package com.example.demo.dao;

import com.example.demo.model.AdminOperateTest;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

import static org.junit.Assert.*;

@SpringBootTest
@RunWith(SpringRunner.class)
public class TestDaoTest {

    @Autowired
    TestDao testDao;
    @Test
    public void findAllLog() {
        AdminOperateTest adminOperateTest = new AdminOperateTest();
        adminOperateTest.setTableName("adminOperateLog");
        List<AdminOperateTest> allLog = testDao.findAllLog(adminOperateTest);
    }
}