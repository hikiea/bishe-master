INSERT INTO `items`(`id`, `userId`, `itemName`, `itemNum`, `itemPicture`, `isBuy`, `money`, `addTime`) VALUES (2, 1, '托马斯小火车', '2台', 'car.jpg', '0', '1000RMB', '2020-12-27 11:07:44');
INSERT INTO `items`(`id`, `userId`, `itemName`, `itemNum`, `itemPicture`, `isBuy`, `money`, `addTime`) VALUES (4, 1, '衣柜', '1个', 'b.jpg', '1', '600RMB', '2020-12-27 11:08:40');
INSERT INTO `items`(`id`, `userId`, `itemName`, `itemNum`, `itemPicture`, `isBuy`, `money`, `addTime`) VALUES (5, 1, '大箱子', '1个', 'b.jpg', '1', '600RMB', '2020-12-27 11:16:16');
INSERT INTO `items`(`id`, `userId`, `itemName`, `itemNum`, `itemPicture`, `isBuy`, `money`, `addTime`) VALUES (7, 1, '大货车', '1', 'cc1cc7c6-f523-4c98-ba88-58bae326f605.jpg', '0', '1RMB', '2021-01-13 10:45:19');
INSERT INTO `items`(`id`, `userId`, `itemName`, `itemNum`, `itemPicture`, `isBuy`, `money`, `addTime`) VALUES (8, 1, '123123', '12321313', '', '', '4214241', '2021-01-13 10:47:06');
INSERT INTO `items`(`id`, `userId`, `itemName`, `itemNum`, `itemPicture`, `isBuy`, `money`, `addTime`) VALUES (10, 1, '123', '123', '', '0', '123', '2021-01-13 10:49:59');
