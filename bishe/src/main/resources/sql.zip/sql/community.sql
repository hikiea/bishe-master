INSERT INTO `community`(`id`, `communityName`, `communityAddress`) VALUES (1, '泰湖新城', '广东省肇庆市端州区信安一路泰湖新城');
INSERT INTO `community`(`id`, `communityName`, `communityAddress`) VALUES (2, '丽湖居', '广东省肇庆市端州区端州四路六号丽湖居');
INSERT INTO `community`(`id`, `communityName`, `communityAddress`) VALUES (6, '敏捷城', '广东省肇庆市敏捷路1号');
INSERT INTO `community`(`id`, `communityName`, `communityAddress`) VALUES (7, '123', '123');
INSERT INTO `community`(`id`, `communityName`, `communityAddress`) VALUES (8, '45', '456');
INSERT INTO `community`(`id`, `communityName`, `communityAddress`) VALUES (9, '7689', '789');
INSERT INTO `community`(`id`, `communityName`, `communityAddress`) VALUES (10, '111', '111');
